<?php
use PHPUnit\Framework\TestCase;

class RecipeControllerTest extends TestCase
{
    public function testListReturnsJsonResponse()
    {
        $repository = $this->createMock(RecipeRepository::class);
        $controller = new RecipeController($repository);
        
        $request = ServerRequestFactory::fromGlobals();
        $response = $controller->list($request);
        
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertEquals('application/json', $response->getHeaderLine('Content-Type'));
    }
}