<?php
namespace App\Service;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Psr\Http\Message\ServerRequestInterface;
use UnexpectedValueException;

class AuthService
{
    private const SECRET_KEY = 'your-secret-key-here'; 
    private const ALGORITHM = 'HS256';
    
    public function generateToken(string $userId): string
    {
        $payload = [
            'iss' => 'recipes-api',
            'sub' => $userId,
            'iat' => time(),
            'exp' => time() + 3600 
        ];
        
        return JWT::encode($payload, self::SECRET_KEY, self::ALGORITHM);
    }

    public function validateToken(ServerRequestInterface $request): ?string
    {
        $authHeader = $request->getHeaderLine('Authorization');
        
        if (!$authHeader || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
            return null;
        }
        
        $token = $matches[1];
        
        try {
            $decoded = JWT::decode($token, new Key(self::SECRET_KEY, self::ALGORITHM));
            return $decoded->sub;
        } catch (\Exception $e) {
            return null;
        }
    }
    public function isAuthenticated(ServerRequestInterface $request): bool
    {
        return $this->validateToken($request) !== null;
    }
}