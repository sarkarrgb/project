<?php
namespace App\Controller;

use Psr\Http\Message\ResponseInterface;
use Laminas\Diactoros\Response\JsonResponse;

class RecipeController
{
    private $repository;

    public function __construct(RecipeRepository $repository)
    {
        $this->repository = $repository;
    }

    public function list($request): ResponseInterface
    {
        $recipes = $this->repository->findAll();
        return new JsonResponse($recipes, 200);
    }
}