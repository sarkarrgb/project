<?php
namespace App\Middleware;

use App\Service\AuthService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Laminas\Diactoros\Response\JsonResponse;

class AuthMiddleware implements MiddlewareInterface
{
    private $authService;
    
    public function __construct(AuthService $authService)
    {
        $this->authService = $authService;
    }
    
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        if (!$this->authService->isAuthenticated($request)) {
            return new JsonResponse(
                ['error' => 'Unauthorized'],
                401,
                ['Content-Type' => ['application/json']]
            );
        }
        
        return $handler->handle($request);
    }
}