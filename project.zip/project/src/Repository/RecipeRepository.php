<?php
namespace App\Repository;

use Doctrine\DBAL\Connection;

class RecipeRepository
{
    private $db;

    public function __construct(Connection $db)
    {
        $this->db = $db;
    }

    public function save(Recipe $recipe): string
    {
        $data = [
            'name' => $recipe->getName(),
            'prep_time' => $recipe->getPrepTime(),
            'difficulty' => $recipe->getDifficulty(),
            'vegetarian' => $recipe->isVegetarian() ? 1 : 0
        ];
        
        if ($recipe->getId()) {
            $this->db->update('recipes', $data, ['id' => $recipe->getId()]);
            return $recipe->getId();
        }
        
        $this->db->insert('recipes', $data);
        return $this->db->lastInsertId();
    }

    // Other CRUD methods...
}