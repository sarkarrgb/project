<?php
namespace App\Model;

class Recipe
{
    private $id;
    private $name;
    private $prepTime;
    private $difficulty;
    private $vegetarian;
    private $ratings = [];

    public function __construct(string $name, int $prepTime, int $difficulty, bool $vegetarian)
    {
        $this->name = $name;
        $this->prepTime = $prepTime;
        $this->difficulty = max(1, min(3, $difficulty));
        $this->vegetarian = $vegetarian;
    }
    public function addRating(int $rating): void
    {
        $this->ratings[] = max(1, min(5, $rating));
    }
}