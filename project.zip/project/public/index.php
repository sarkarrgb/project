<?php
require __DIR__ . '/../vendor/autoload.php';

use Laminas\Diactoros\ServerRequestFactory;
use League\Route\Router;
use Symfony\Component\DependencyInjection\ContainerBuilder;

// Setup DI Container
$container = new ContainerBuilder();
$container->register(Router::class, Router::class);
// Add more service definitions...

// Routing
$router = $container->get(Router::class);
$router->get('/recipes', 'App\\Controller\\RecipeController::list');
$router->post('/recipes', 'App\\Controller\\RecipeController::create')
    ->middleware(new App\Middleware\AuthMiddleware());
$router->get('/recipes/{id}', 'App\\Controller\\RecipeController::get');
$router->put('/recipes/{id}', 'App\\Controller\\RecipeController::update')
    ->middleware(new App\Middleware\AuthMiddleware());
$router->delete('/recipes/{id}', 'App\\Controller\\RecipeController::delete')
    ->middleware(new App\Middleware\AuthMiddleware());
$router->post('/recipes/{id}/rating', 'App\\Controller\\RecipeController::rate');
$router->get('/recipes/search', 'App\\Controller\\RecipeController::search');

$request = ServerRequestFactory::fromGlobals();
$response = $router->dispatch($request);
(new Laminas\HttpHandlerRunner\Emitter\SapiEmitter)->emit($response);